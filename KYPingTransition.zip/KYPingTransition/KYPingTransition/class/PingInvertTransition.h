//
//  PingInvertTransition.h
//  KYPingTransition
//
//  Created by zengzheying on 15/12/17.
//  Copyright (c) 2015年 zengzheying. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ZYPercentDrivenInteractiveTransition.h"

@interface PingInvertTransition : NSObject <UIViewControllerAnimatedTransitioning>
//@interface PingInvertTransition : ZYPercentDrivenInteractiveTransition

@end