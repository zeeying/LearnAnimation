//
//  PingTransition.h
//  KYPingTransition
//
//  Created by zengzheying on 15/12/17.
//  Copyright (c) 2015年 zengzheying. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface PingTransition : NSObject <UIViewControllerAnimatedTransitioning>

- (void)finishInteractiveTransition;
- (void)cancalInteractiveTransition;

@end
