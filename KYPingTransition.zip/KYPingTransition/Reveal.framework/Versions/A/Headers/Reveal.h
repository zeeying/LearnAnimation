//  Copyright (c) 2013 Itty Bitty Apps Pty Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IBARevealLogger.h"
#import "IBARevealLoader.h"

//! Project version number for Reveal.
FOUNDATION_EXPORT double RevealVersionNumber;

//! Project version string for Reveal.
FOUNDATION_EXPORT const unsigned char RevealVersionString[];
